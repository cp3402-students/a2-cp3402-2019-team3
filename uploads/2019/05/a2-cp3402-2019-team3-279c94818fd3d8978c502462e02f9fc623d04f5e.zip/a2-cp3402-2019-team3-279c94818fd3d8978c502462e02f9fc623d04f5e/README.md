# a2-cp3402-2019-team3
a2-cp3402-2019-team3 created by GitHub Classroom


Team Members:

Bonnie Thompson

Max Dunsmore

James Collison

Jacob Negri
